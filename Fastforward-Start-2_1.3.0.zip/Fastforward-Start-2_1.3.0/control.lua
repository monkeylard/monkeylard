if script.level.campaign_name then return end
if script.level.level_name == "sandbox" then return end


local START_ITEMS = require("start-items")


local function find_chest()
	local chest_name = "steel-chest"
	if game.entity_prototypes[chest_name] == nil then
		log("Starting chest "..chest_name.." is not a valid entity prototype, picking a new container from prototype list")
		for name, chest in pairs(game.entity_prototypes) do
			if chest.type == "container" then
				return name
			end
		end
	end
	return chest_name
end

local function on_game_created_from_freeplay()
	global.is_init = true
	local surface = game.get_surface(1)
	if not (surface and surface.valid) then return end

	local neutral_force = game.forces["neutral"]
	local container_name, position, target
	local target = surface.find_entities_filtered{position = {0, 0}, radius = 100, name = "crash-site-spaceship", type = "container"}[1]
	if target and target.valid then
		container_name = target.name
		position = target.position
	else
		container_name = find_chest()
		position = surface.find_non_colliding_position(container_name, {0, 0}, 100, 1)
		if position == nil then
			log("Can't find non colliding position for " .. container_name)
			return	
		end
		target = surface.create_entity{name = container_name, position = position, force = neutral_force, create_build_effect_smoke = false}
	end

	global.is_freeplay_game = true

	for _, item in pairs(START_ITEMS) do
		if game.item_prototypes[item[1]] then
			local items = {name = item[1], count = item[2]}
			if target.can_insert(items) then
				target.insert(items) -- TODO: check inserted count of items
			else
				container_name = find_chest() -- this is dirty
				position = surface.find_non_colliding_position(container_name, position, 30, 1)
				if position == nil then
					log("Can't find non colliding position for " .. container_name)
					return	
				end
				target = surface.create_entity{name = container_name, position = position, force = neutral_force, create_build_effect_smoke = false}
			end
		else
			log("\""..item[1].."\" doesn't exist in the game, please check spelling.")
		end
	end
end

local function on_freeplayer_created(event)
	if global.is_freeplay_game then return end
	if global.is_init ~= true then
		on_game_created_from_freeplay()
		if global.is_freeplay_game then return end
	end

	local player = game.get_player(event.player_index)
	if not (player and player.valid) then return end	
	for _, item in pairs(START_ITEMS) do
		if game.item_prototypes[item[1]] then
			player.insert{name = item[1], count = item[2]}
		end
	end
end

local function on_player_created_straight(event)
	local player = game.get_player(event.player_index)
	if not (player and player.valid) then return end

	for _, item in pairs(START_ITEMS) do
		if game.item_prototypes[item[1]] then
			player.insert{name = item[1], count = item[2]}
		end
	end
end


if script.level.level_name == "freeplay" then
	script.on_event(defines.events.on_player_created, on_freeplayer_created)
else
	script.on_event(defines.events.on_player_created, on_player_created_straight)
end
