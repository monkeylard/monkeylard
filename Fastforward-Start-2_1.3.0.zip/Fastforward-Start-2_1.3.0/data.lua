local ship = data.raw.container["crash-site-spaceship"]
if ship then
	if ship.inventory_size < 50 then
		ship.inventory_size = 50
	end
end