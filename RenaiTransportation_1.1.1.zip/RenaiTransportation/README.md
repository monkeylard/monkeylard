# Renai Transportation

Quite possibly the jankest Factorio mod ever made

but at least the memes are good


  Features include Thrower Inserters that YEET items through the air, and Bounce Pads that can make those items fly further through chained bounces. The Player Launcher lets you do the same with your character.
