if aai_vehicle_exclusions then
    table.insert(aai_vehicle_exclusions, "RTPropCar")
end