data:extend({

  {
    type = "item-subgroup",
    name = "throwers",
    group = "logistics",
    order = "ca"
  },

  {
    type = "item-subgroup",
    name = "RT",
    group = "logistics",
    order = "cb"
  }
})