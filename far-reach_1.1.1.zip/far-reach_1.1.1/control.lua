
function far_reach_apply_settings()
    local settings = settings.global
    for _,player in pairs(game.players) do
        if player.character then
            player.character_build_distance_bonus = settings["far-reach-build-distance-bonus"].value
            player.character_reach_distance_bonus = settings["far-reach-reach-distance-bonus"].value
            player.character_resource_reach_distance_bonus = settings["far-reach-resource-reach-distance-bonus"].value
            player.character_item_drop_distance_bonus = settings["far-reach-item-drop-distance-bonus"].value
        end
    end
end

script.on_init(far_reach_apply_settings)

script.on_configuration_changed(
	function(data)
		log("on_configuration_changed")
		far_reach_apply_settings()
	end
)

script.on_event({defines.events.on_runtime_mod_setting_changed, defines.events.on_player_joined_game, defines.events.on_player_changed_force, defines.events.on_player_respawned, defines.events.on_player_created, defines.events.on_cutscene_cancelled, defines.events.on_cutscene_waypoint_reached},
	function(event)
		far_reach_apply_settings()
	end
)

-- fix for https://mods.factorio.com/mod/jetpack resetting far reach settings.
if script.active_mods["jetpack"] then
	remote.add_interface("far-reach", {
		on_character_swapped = function(event)
        --https://mods.factorio.com/mod/jetpack looks for remote interface called "on_character_swapped" specifically
        --{new_unit_number = uint, old_unit_number = uint, new_character = luaEntity, old_character = luaEntity}
			far_reach_apply_settings()
		end
	})
end
