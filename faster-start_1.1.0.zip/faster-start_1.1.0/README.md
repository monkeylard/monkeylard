# faster-start
Mod for Factorio that gives some items to new players to speed up game beginning
