informatron_make_image("informatron_image_1", "__informatron__/graphics/informatron/example_image.png", 451, 400)
